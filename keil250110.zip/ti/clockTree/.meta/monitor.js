exports = {

    config : [
        {
            name: "enable",
            displayName: "Enable LFCLK Monitor",
            description: "Enable to use monitor for LFXT, EXLF failure",
            default: false
        }
    ],
    maxInstances: 1

}
