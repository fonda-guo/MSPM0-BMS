2025/2/12
current BMS software include:
1.Read/config AFE
2.Coulomb counter of single bat/BOX
3.Capcity calibration after reaching 2.7/3.58
4.Cell balance config
5.Initial SOC estimate

2025/2/20
current BMS software include:
1.Read/config AFE
2.Coulomb counter of single bat/BOX
3.Capcity calibration after reaching 2.7/3.58
4.Cell balance config
5.Initial SOC estimate
6.SOC calibration based on voltage